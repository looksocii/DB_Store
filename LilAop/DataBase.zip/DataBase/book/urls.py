from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('info/', views.info_all, name='book_all'),
    path('info/<slug:book_id>/', views.info, name='book_detail'),
    path('add/', views.add, name='book_add'),
    path('add/add_suc/', views.suc, name='add_suc'),
]