from django.db import models
import mysql.connector

def connection():
    con = mysql.connector.connect(
    user='it61070139_test', 
    password='999999999', 
    host='ihost.it.kmitl.ac.th', 
    database='it61070139_dbSTD'
    )
    return con

def getData():
    con = connection()
    cursor = con.cursor()
    sql = ("select * from BookStore")
    cursor.execute(sql)
    data = cursor.fetchall()
    return data

class Book(models.Model):
    id_book = models.IntegerField(primary_key=True)
    name_book = models.CharField(max_length=30)
    author_book = models.CharField(max_length=20)
    category_book = models.CharField(max_length=20)
    price_book = models.FloatField(max_length=10)