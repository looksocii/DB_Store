from django.http import HttpResponse
from django.shortcuts import render
from . import models
from book.models import Book
import mysql.connector

# Create your views here.
def index(request):
    data = models.getData()
    context = {
        'data': data
    }
    return render(request, 'index.html', context=context)

def info(request, book_id):
    data = models.getData()
    data_list = {}
    for info in data:
        if info[3] == book_id:
            data_list = info
    context = {
        'data_list': data_list
    }
    return render(request, 'info.html', context=context)

def info_all(request):
    data = models.getData()
    context = {
        'data': data
    }
    return render(request, 'all.html', context=context)

def add(request):
    return render(request, 'add.html')

def suc(request):
    con = mysql.connector.connect(
    user='it61070139_aop', 
    password='00000', 
    host='ihost.it.kmitl.ac.th', 
    database='it61070139_DBstore'
    )
    cursor = con.cursor()
    sql = ("select * from book_book")
    cursor.execute(sql)
    data = cursor.fetchall()

    bookID = len(data)+1
    name = request.GET['name_book']
    author = request.GET['author_book']
    category = request.GET['category_book']
    price = float(request.GET['price_book'])

    b = Book(id_book=bookID, name_book=name, author_book=author, category_book=category, price_book=price)
    b.save()
    return render(request, 'success.html')