from django.apps import AppConfig


class BookConfig(AppConfig):
    name = 'book'
